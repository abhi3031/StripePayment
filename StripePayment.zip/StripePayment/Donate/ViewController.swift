
import UIKit
import Stripe

class ViewController: UIViewController,STPAddCardViewControllerDelegate {//,PKPaymentAuthorizationViewControllerDelegate{

    @IBOutlet weak var lblmsgBox: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblmsgBox.text = ""
    }
    
    @IBAction func PaymentTapped(_ sender: UIButton) {
    
        /*let addCartViewController = STPAddCardViewController()
        addCartViewController.delegate = self
        let navigationController = UINavigationController(rootViewController: addCartViewController)
        self.present(navigationController, animated: true, completion: nil)*/
        let paymentRequest = Stripe.paymentRequest(withMerchantIdentifier: STPPaymentConfiguration.shared().appleMerchantIdentifier!, country: "IN", currency: "INR")
        paymentRequest.paymentSummaryItems = [PKPaymentSummaryItem(label: "red hat", amount: NSDecimalNumber(string: "50.00")),PKPaymentSummaryItem(label: "black hat", amount: NSDecimalNumber(string: "60.00"))]
        if Stripe.canSubmitPaymentRequest(paymentRequest) {
            
            let paymentAuthorizationVc = PKPaymentAuthorizationViewController(paymentRequest: paymentRequest)
            //paymentAuthorizationVc.delegate = self
            self.present(paymentAuthorizationVc, animated: true, completion: nil)
        }
        else{
            
            print("Apple pay is not configure properly")
        }
    }

    func addCardViewControllerDidCancel(_ addCardViewController: STPAddCardViewController) {
        
        dismiss(animated: true, completion: nil)
    }
    func addCardViewController(_ addCardViewController: STPAddCardViewController, didCreateToken token: STPToken, completion: @escaping STPErrorBlock) {
        
        dismiss(animated: true, completion: nil)
        print("Printing Stripe Response: \(token.allResponseFields)\n\n")
        print("Printing Stripe Token: \(token.tokenId) \n\n")
        lblmsgBox.text = "Transaction success \n\n Here is the token: \(token.tokenId) Card type: \(token.card?.funding.rawValue) \n\n send this token or detail to your backend server to complete this payment"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

